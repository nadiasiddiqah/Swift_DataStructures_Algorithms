// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.


// MARK: - USING ARRAY TO CREATE A QUEUE

// 1. Create generic Stack struct that adopts Queue protocol
public struct QueueStack<T>: Queue {
    
    // 2. Create two stacks
    // Right stack used to enqueue new elements
    // Left stack (reverse of right stack) used to dequeue elements (in FIFO order)
    private var leftStack: [T] = []
    private var rightStack: [T] = []
    
    public init() {}
    
    // 3. Add computed properties of Queue protocol
    public var isEmpty: Bool {
        leftStack.isEmpty && rightStack.isEmpty
    }
    
    public var peek: T? {
        // If leftStack isEmpty, first element is righStack's first
        // If leftStack is NOT empty, first element is leftStack's last
        leftStack.isEmpty ? rightStack.first : leftStack.last
    }
    
    // 4. Add functions of Queue protocol
    public mutating func enqueue(_ element: T) -> Bool {
        // Enqueue into rightStack
        rightStack.append(element)
        return true
    }
    
    public mutating func dequeue() -> T? {
        // Only if leftStack isEmpty, update it all of rightStack's reversed elements
        // Then, invalidate rightStack (with removeAll)
        if leftStack.isEmpty {
            leftStack = rightStack.reversed()
            rightStack.removeAll()
        }
        
        // Remove last element of leftStack
        return leftStack.popLast()
    }
}


// MARK: - DEBUG AND TEST
extension QueueStack: CustomStringConvertible {
    public var description: String {
        // Print all elements if reversing leftStack + rightStack
        String(describing: leftStack.reversed() + rightStack)
    }
}

// MARK: - TEST CASE
var queue = QueueStack<String>()
for i in ["Ray", "Brian", "Eric"] {
    queue.enqueue(i)
}
queue               // ["Ray", "Brian", "Eric"]
queue.dequeue()     // "Ray"
queue               // ["Brian", "Eric"]
queue.peek          // "Brian"
