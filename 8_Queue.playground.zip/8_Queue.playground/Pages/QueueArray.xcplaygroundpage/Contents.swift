// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.

// MARK: - USING ARRAY TO CREATE A QUEUE

// 1. Create generic QueueArray struct that adopts Queue protocol
public struct QueueArray<T>: Queue {
    private var array: [T] = []
    
    public init() {}
    
    // 2. Add computed properties of Queue protocol
    public var isEmpty: Bool {
        // O(1): Check if queue is empty
        array.isEmpty
    }
    
    public var peek: T? {
        // O(1): Return first element in the queue
        array.first
    }
    
    // 3. Add functions of Queue protocol
    public mutating func enqueue(_ element: T) -> Bool {
        // O(1): Add element to back of the empty (arrays have empty space at the back)
        array.append(element)
        return true
    }
    
    public mutating func dequeue() -> T? {
        guard !isEmpty else { return nil }
        
        // O(n): Removing first element, requires reshifting all the other elements in memory
        return array.removeFirst()
    }
}

// MARK: - DEBUG AND TEST
extension QueueArray: CustomStringConvertible {
    public var description: String {
        String(describing: array)
    }
}

// MARK: - TEST CASE
var queue = QueueArray<String>()
for i in ["Ray", "Brian", "Eric"] {
    queue.enqueue(i)
}
queue               // ["Ray", "Brian", "Eric"]
queue.dequeue()     // "Ray"
queue               // ["Brian", "Eric"]
queue.peek          // "Brian"
           
