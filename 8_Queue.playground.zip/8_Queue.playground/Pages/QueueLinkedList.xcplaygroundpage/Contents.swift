// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.

// MARK: - USING LINKED LIST TO CREATE A QUEUE

// 1. Create generic QueueLinkedList class that adopts Queue protocol
public class QueueLinkedList<T>: Queue {
    private var list = DoublyLinkedList<T>()
    
    public init() {}
    
    // 2. Add computed properties of Queue protocol
    public var isEmpty: Bool {
        list.isEmpty
    }
    
    public var peek: T? {
        list.first?.value
    }
    
    // 3. Add functions of Queue protocol
    public func enqueue(_ element: T) -> Bool {
        list.append(element)
        return true
    }
    
    public func dequeue() -> T? {
        guard !list.isEmpty, let firstElement = list.first else {
            return nil
        }
        
        return list.remove(firstElement)
    }
}

// MARK: - DEBUG AND TEST
extension QueueLinkedList: CustomStringConvertible {
    public var description: String {
        String(describing: list)
    }
}

// MARK: - TEST CASE
var queue = QueueLinkedList<String>()
for i in ["Ray", "Brian", "Eric"] {
    queue.enqueue(i)
}
queue               // ["Ray", "Brian", "Eric"]
queue.dequeue()     // "Ray"
queue               // ["Brian", "Eric"]
queue.peek          // "Brian"
