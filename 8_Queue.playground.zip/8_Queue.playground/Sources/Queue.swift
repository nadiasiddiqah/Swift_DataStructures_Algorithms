// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.

public protocol Queue {
  
  associatedtype Element

  // Adds element to the end of the queue (returns true if successful)
  mutating func enqueue(_ element: Element) -> Bool
    
  // Removes element at the front of the queue (returns removed element)
  mutating func dequeue() -> Element?
    
  // Checks if queue is empty
  var isEmpty: Bool { get }
    
  // Returns element at the front of the queue (without removing it)
  var peek: Element? { get }
}
