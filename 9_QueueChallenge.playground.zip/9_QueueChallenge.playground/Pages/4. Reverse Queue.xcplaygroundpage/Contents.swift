// Copyright (c) 2018 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
//: [Previous Challenge](@previous)
/*:
 ## 4. Reverse Queue
 
 Implement a method to reverse the contents of a queue.
 
 > Hint: The `Stack` data structure has been included in the **Sources** folder.
 */
extension QueueArray {
    
    mutating func reversed() -> QueueArray {
        let queue = self
        
        // Return reversed queue
        return queue
    }
}


// MARK: - TEST
var queue = QueueArray<String>()
queue.enqueue("1")
queue.enqueue("21")
queue.enqueue("18")
queue.enqueue("42")

print("before: \(queue)")
print("after: \(queue.reversed())")

//: [Next Challenge](@next)
// MARK: - SOLUTION
//mutating func reversed() -> QueueArray {
//    // 1. Create stack
//    var stack = Stack<Element>()
//    
//    // 2. Create copy of queue
//    var queue = self
//    
//    // Push all queue elements into stack
//    while let element = queue.dequeue() {
//        stack.push(element)
//    }
//    
//    // Pop stack elements + insert into queue
//    while let element = stack.pop() {
//        queue.enqueue(element)
//    }
//    
//    // Return reversed queue
//    return queue
//}
