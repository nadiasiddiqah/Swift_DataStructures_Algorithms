import UIKit

// MARK: Is Unique
// Q: Implement an algorithm to determine if a string has all unique characters. What if you cannot use additional data structures?

func isUnique(input: String) -> Bool {
    guard !input.isEmpty else { return false }
    return Set(input).count == input.count
}


// MARK: Check Permutation
// Q: Given two strings, write a method to decide if one is a permutation of the other.

//func isPermutation(input1: String, input2: String) -> Bool {
//    guard input1.count == input2.count else { return false }
//}
//
//var array = ["Pink", "Red", "Yellow"]
//array.removeLast()

struct User: Hashable {
    var name: String
}
