// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
/*:
 # Linked List Challenges
 ## Challenge 1: Print in reverse

 Create a function that prints the nodes of a linked list in reverse order.
 */
func printInReverse<T>(_ list: LinkedList<T>) {
   
}

// MARK: - Test it out
//var list = LinkedList<Int>()
//for i in 1...3 {
//    list.push(i)
//}
//printInReverse(list)
//: [Next Challenge](@next)







// My solution
//func printInReverseMySolution<T>(_ list: LinkedList<T>) {
//    print("list: \(list)")
//    
//    var copied = list
//
//    for _ in 0..<list.count {
//        print(copied.removeLast()!)
//    }
//}

// Recursive solution
func printInReverseSolution<T>(_ list: LinkedList<T>) {
    print("list: \(list)")  // 3 -> 2 -> 1

    // O(n): Recursive solution
    printInReverseSolution(list.head)
}

private func printInReverseSolution<T>(_ node: Node<T>?) {
    // Check if node exists
    // If node is nil, end recursion bc you're at the end of the list
    guard let node = node else { return }

    // Recursive call, calling same function to check the next node
    print(node.next)
    printInReverseSolution(node.next)

    // Below is called after node.next == nil in recursion above
    // As recursive statements unravel, node data gets printed out
    print(node.value)
}

var list = LinkedList<Int>()
for i in 1...3 {
    list.push(i)
}
printInReverseSolution(list)  // 1
                              // 2
                              // 3

// MARK: - Solution logic
// O(n): Uses recursive function to traverse and process each node of the list
// 1. Use recursion to traverse down the nodes of the list
// 2. The parameter for the recursion is a node
// 3. Within recursive function, check if node exists
// 4. If so, pass the node's next into recursive function
// 5. When, guard statement (aka recursive function's end condition is reached bc we're at the last node)
// 6. Recursive statements unravels rapidly, so each node's value gets printed out

