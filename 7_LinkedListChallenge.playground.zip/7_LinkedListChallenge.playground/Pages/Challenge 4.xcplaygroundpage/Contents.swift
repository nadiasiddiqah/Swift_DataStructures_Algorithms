// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
/*:
 [Previous Challenge](@previous)
 ## Challenge 4: Merge two lists

 Create a function that takes two sorted linked lists and merges them into a single sorted linked list. Your goal is to return a new linked list that contains the nodes from two lists in sorted order. You may assume the sort order is ascending.
 */

import Darwin
//func mergeSorted<T: Comparable>(_ left: LinkedList<T>,
//                                _ right: LinkedList<T>) -> LinkedList<T> {
//    return LinkedList<T>
//}


// MARK: - TEST CASE
var list1 = LinkedList<Int>()
for i in [11, 10, 4, 1] {
    list1.push(i)
}

var list2 = LinkedList<Int>()
for i in [6, 3, 2, 1] {
    list2.push(i)
}

//mergeSorted(list1, list2)  // 1 -> 1 -> 2 -> 3 -> 4 -> 6 -> 10 -> 11
//: [Next Challenge](@next)



// MARK: - SOLUTION LOGIC
// O(m + n): To loop through # of nodes in first and second lists
// 1. Check if either list is empty, if so, return existing list
// 2. Create newHead node (sets lowest Int)
// 3. Create tail node (updates with largest Int)
// 4. Create currentLeft to traverse through left list
// 5. Create currentRight to traverse through right list
// 6. Unwrap currentLeft and currentRight nodes to compare their values
       // a. If currentLeft's value < currentRight's value
          // i. Set newHead to currentLeft node (lowest Int)
          // ii. Update currentLeft to its next node
       // b. If currentRight's value < or == currentLeft's value
          // i. Set newHead to currentRight node (lowest Int)
          // ii. Update currentRight to its next node
       // c. Update tail with newHead
// 7. Use while loop to iterate through each list until we reach the end of one list
      // a. If currentLeft's value < currentRight's value
         // i. Set tail's next to currentLeft node (next lowest Int)
         // ii. Update currentLeft to its next node
      // b. If currentRight's value < currentLeft's value
         // i. Set tail's next to currentRight node (next lowest Int)
         // ii. Update currentRight to its next node
      // c. Update tail with tail's next
// 8. Append remainder of the nodes (as tail's next) when while statement stops
// 9. Create sortedList
      // a. Add its head (using newHead)
      // b. Add its tail (using while loop to iterate through tail's next)



// MARK: - SOLUTION
func mergeSortedSolution<T: Comparable>(_ left: LinkedList<T>,
                                _ right: LinkedList<T>) -> LinkedList<T> {
    print(left)
    print(right)
    
    // If left is empty, return right
    guard !left.isEmpty else {
        return right
    }
    
    // If right is empty, return left
    guard !right.isEmpty else {
        return left
    }
    
    var newHead: Node<T>?
    var tail: Node<T>?
    
    // Traverse each node in both lists
    var currentLeft = left.head
    var currentRight = right.head
    
    // Sets newHead + tail
    if let leftNode = currentLeft, let rightNode = currentRight {
        // Set newHead
        if leftNode.value < rightNode.value {
            newHead = leftNode
            currentLeft = leftNode.next
        } else {
            newHead = rightNode
            currentRight = rightNode.next
        }
        
        // Update tail with newHead node
        tail = newHead
        print("newHead: \(tail?.value)")
    }
    
    // O(m + n): Continues until one of the lists reaches its end
    // Update tail with tail's next node
    while let leftNode = currentLeft, let rightNode = currentRight {
        // Compare nodes from each list to update the tail
        if leftNode.value < rightNode.value {
            tail?.next = leftNode
            currentLeft = leftNode.next
        } else {
            tail?.next = rightNode
            currentRight = rightNode.next
        }
        
        // Update tail with tail's next node
        tail = tail?.next
        print("tailNext: \(tail?.value)")
    }
    
    // Appends the remainder of the nodes
    if let leftNodes = currentLeft {
        tail?.next = leftNodes
    }
    
    if let rightNodes = currentRight {
        tail?.next = rightNodes
    }
    
    // Create new sorted list
    var sortedList = LinkedList<T>()
    sortedList.head = newHead
    sortedList.tail = tail
    
    print("solution: \(sortedList)")
    return sortedList
}

mergeSortedSolution(list1, list2)
