// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
/*:
 [Previous Challenge](@previous)
 ## Challenge 2: Find the middle node

 Create a function that finds the middle node of a linked list.
 */
// if odd number of node.value, middle includes nil
// if even number of node.value, middle doesn't include nil

func getMiddle<T>(_ list: LinkedList<T>) -> Node<T>? {
    
    return nil
}

var list = LinkedList<Int>()
for i in (1...3).reversed() {
    list.push(i)
}
getMiddle(list)
//: [Next Challenge](@next)









//func getMiddleMySolution<T>(_ list: LinkedList<T>) -> Node<T>? {
//    print(list)
//
//    if (list.count + 1) % 2 == 0 {
//        let middleNode = list.node(at: list.count / 2)
//        if let value = middleNode?.value {
//            print(value)
//        }
//        return middleNode
//    } else {
//        let middleNode = list.node(at: (list.count + 1) / 2)
//        if let value = middleNode?.value {
//            print(value)
//        }
//        return middleNode
//    }
//}


func getMiddleSolution<T>(_ list: LinkedList<T>) -> Node<T>? {
    print(list)
    var slow = list.head
    var fast = list.head
    
    // O(n)
    while let nextFast = fast?.next {
        slow = slow?.next
        fast = nextFast.next
    }
    
    return slow
}

var list1 = LinkedList<Int>()
for i in (1...4).reversed() {
    list1.push(i)
}
getMiddleSolution(list1)   // 3

var list2 = LinkedList<Int>()
for i in (1...3).reversed() {
    list2.push(i)
}
getMiddleSolution(list2)  // 2


// MARK: - SOLUTION LOGIC:
// O(n): Uses the runner's technique, where if there is a next node, you update fast to the next node of nextFast, effectively traversing the list twice
// 1. Have two references go down the nodes of the list
// 2. First reference increments by one
// 3. Second reference increments twice as fast (only if increment by one is not nil)
// 4. When second reference reaches nil, the first reference will be in the middle

