// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
/*:
 [Previous Challenge](@previous)
 ## Challenge 3: Reverse a linked list

 Create a function that reverses a linked list. You do this by manipulating the nodes so that they’re linked in the other direction.
 */
extension LinkedList {
    
  mutating func reverse() {
      
  }
}

var list1 = LinkedList<Int>()
for i in (1...3).reversed() {
    list1.push(i)
}
list1.reverse()

//: [Next Challenge](@next)







// MARK: - SOLUTION
extension LinkedList {
    
  mutating func reverseSolution() {
      var reversed = LinkedList<Value>()
      
      // O(n) Push current values to reversed
      for value in self {
          reversed.push(value)
      }
      
      head = reversed.head
  }
}

// MARK: - SOLUTION LOGIC
// 1. O(n): Loop through current values in self (list)
// 2. Push each value into reversed
// 3. Set list's head to reversed's head
