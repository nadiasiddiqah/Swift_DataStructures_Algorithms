// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
/*:
 [Previous Challenge](@previous)
 ## Challenge 5: Remove all occurrences of a specific element

 Create a function that removes all occurrences of a specific element from a linked list. The implementation is similar to the `remove(at:)` method that you implemented for the linked list.
 */

extension LinkedList where Value: Equatable {
  
  mutating func removeAll(_ value: Value) {
      
  }
}

// MARK: - TEST CASES
var list = LinkedList<Int>()
for i in [1, 3, 3, 3, 3] {
    list.append(i)
}

list.removeAll(3)

example(of: "deleting duplicate nodes") {
  var list = LinkedList<Int>()
  list.push(3)
  list.push(2)
  list.push(2)
  list.push(1)
  list.push(1)
  list.removeAll(3)
  print(list)
}







// MARK: - SOLUTIONS
extension LinkedList where Value: Equatable {
  
  mutating func removeAllMySolution(_ value: Value) {
      
      var currentNode = self.head
      var updatedList = LinkedList<Value>()

      // O(n)
      while let node = currentNode {
          if node.value != value {
              updatedList.append(node.value)
          }
          currentNode = node.next
      }

      self = updatedList
      print(self)
  }
}


extension LinkedList where Value: Equatable {
  
  mutating func removeAllSolution(_ value: Value) {
      
      var prev = head
      var current = head?.next

      while let currentNode = current {
          guard currentNode.value != value else {
              prev?.next = currentNode.next
              current = prev?.next
              continue
          }
          prev = current
          current = current?.next
      }

      tail = prev
  }
}
