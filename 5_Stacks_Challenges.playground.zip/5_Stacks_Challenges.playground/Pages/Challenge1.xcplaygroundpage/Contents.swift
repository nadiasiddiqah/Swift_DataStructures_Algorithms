// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.
/*:
 # Stack Challenges
 
 ## #1. Reverse an Array
 
 Create a function that prints the contents of an array in reversed order.
 */

let array: [Int] = [1, 2, 3, 4, 5]

// T = generic type
func printInReverse<T>(_ array: [T]) {
    var stack = Stack<T>()
    
    // O(n): Push elements onto stack
    for i in array {
        stack.push(i)
    }
    
    // O(n): Pop elements off stack
    while let value = stack.pop() {
        print(value)
    }
}

// O(n)
printInReverse(array)

// MARK: - SOLUTION LOGIC
// 1. Stacks can be used to facilitate backtracking
// 2. If push a sequence of values into the stack
// 3. Then, you pop the stack, it'll give you the reverse order
//: [Next Challenge](@next)
