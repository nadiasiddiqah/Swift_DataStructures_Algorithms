import Foundation

// 1. Create Stack struct that can accept any Element type
public struct Stack<Element> {
    // 2. Storage type for Stack is an array
    // Arrays = O(1) insertions and deletions at end
    private var storage: [Element] = []
    
    // Set storage to elements 
    public init(_ elements: [Element]) {
        storage = elements
    }
    
    // MARK: - ESSENTIAL FUNCTIONS
    // O(1): Push operation (add element on top of stack)
    public mutating func push(_ element: Element) {
        // Use array's append to add element to end
        storage.append(element)
    }

    // O(1): Pop operation (remove element at top of stack)
    @discardableResult
    public mutating func pop() -> Element? {
        // Use array's popLast to remove element at the end
        storage.popLast()
    }

    // MARK: - NON-ESSENTIAL FUNCTIONS
    // To peek at top element without mutating its contents
    public func peek() -> Element? {
        storage.last
    }
    
    public var isEmpty: Bool {
        peek() == nil
    }
}

extension Stack: CustomDebugStringConvertible {
    public var debugDescription: String {
        """
        ----top----
            \(storage.map { "\($0)" }.reversed().joined(separator: "\n"))
        -----------
        """
    }
}

extension Stack: ExpressibleByArrayLiteral {
    public init(arrayLiteral elements: Element...) {
        storage = elements
    }
}
