import Foundation

public struct LinkedList<Value> {
    
    // Head = first node; Tail = last node
    public var head: Node<Value>?
    public var tail: Node<Value>?
    
    public init() {
        
    }
    
    public var isEmpty: Bool {
        head == nil
    }
    
    // MARK: - ADD VALUES TO LIST METHODS
    
    // O(1): Push method
    // AKA: Head-first insertion (adds value at front of list)
    public mutating func push(_ value: Value) {
        copyNodes()
        head = Node(value: value, next: head)
        
        // If list is empty, set new node as both the head + tail
        if tail == nil {
            tail = head
        }
    }
    
    
    // O(1): Append method
    // AKA: Tail-first insertion (adds value to end of list)
    public mutating func append(_ value: Value) {
        copyNodes()
        // 1: If list is empty, use push method to push new node as head + tail
        guard !isEmpty else {
            push(value)
            return
        }
        
        // 2: Set new node as the current tail's next 
        tail!.next = Node(value: value)
        
        // 3: Set new node as the tail
        tail = tail!.next
    }
    
    
    // O(1): Insert(after:) method - inserts a node after a given node
    // First, find the node at the given index, and then its next to the new node
    
    // Step 1 - O(i): node(at:) method
    // i = given index
    // Returns node at a given index
    public func node(at index: Int) -> Node<Value>? {
        // 1
        var currentNode = head   // creates new reference to head
        var currentIndex = 0     // tracks current number of traversals
        
        // 2: Moves reference down the list until you reach given index
        // Empty lists or out-of-bound index will result in nil return value
        while currentNode != nil && currentIndex < index {
            currentNode = currentNode!.next
            currentIndex += 1
        }
        
        return currentNode
    }
    
    // Step 2: call insert(after:) method
    // 1. @discardableResult = let callers ignore return value of method
    @discardableResult
    public mutating func insert(_ value: Value,
                                after node: Node<Value>) -> Node<Value> {
        copyNodes()
        // 2: If insertion is at the tail node, you use append method
        guard tail !== node else {
            append(value)
            return tail!
        }
        
        // 3: Link up new node with the rest of the list + return new node
        node.next = Node(value: value, next: node.next)
        return node.next!
    }
    
    
    
    // MARK: - REMOVE VALUES TO LIST METHODS
    
    // Pop method: Removes value from head + returns value
    // Optional bc list can be empty
    @discardableResult
    public mutating func pop() -> Value? {
        copyNodes()
        defer {
            // Set head to head's next
            head = head?.next
            
            // Check if head is empty (if so, head is also tail)
            if isEmpty {
                tail = nil
            }
        }
        return head?.value
    }
    
    // removeLast method: Removes value from tail
    // Requires you to go through entire list until you grab the last two nodes
    @discardableResult
    public mutating func removeLast() -> Value? {
        copyNodes()
        // 1: Check if head is nil
        // If so, nothing to remove -> return nil
        guard let head = head else { return nil }
        
        // 2. Check head is not also tail
        // If so, pop off + return head
        guard head.next != nil else { return pop() }
        
        // 3. Search for next node until current.next == nil
        // This means, current is the last node of the list
        var prev = head
        var current = head
        
        while let next = current.next {
            prev = current
            current = next
        }
        
        // 4. Disconnect current node (last/tail node) of the list
        // Set prev node's next to nil
        // Set tail to prev node
        prev.next = nil
        tail = prev
        return current.value  // Returns removed current node (old tail)
    }
    
    
    // remove(after:) method: Removes value after a particular node
    // First, find node before the node you want removed, and unlink it
    
    @discardableResult
    public mutating func remove(after node: Node<Value>) -> Value? {
        guard let node = copyNodes(returningCopyOf: node) else { return nil }
        defer {
            // Check if node's next is tail
            // If so, set tail to node (to remove tail)
            if node.next === tail {
                tail = node
            }
            
            // Set node's next to the its next (to remove node's next)
            node.next = node.next?.next
        }
        
        // Return node that needs to be removed 
        return node.next?.value
    }
    
    
    // MARK: - ADD VALUE SEMANTICS TO LINKED LIST
    private mutating func copyNodes() {
        // Check if head doesn't have a single strong reference
        guard !isKnownUniquelyReferenced(&head) else { return }
        
        guard var oldNode = head else { return }
        
        head = Node(value: oldNode.value)
        var newNode = head
        
        while let nextOldNode = oldNode.next {
            newNode!.next = Node(value: nextOldNode.value)
            newNode = newNode!.next
            
            oldNode = nextOldNode
        }
        
        tail = newNode
    }
    
    // Similar to above function, but it returns the newly copied node based on the passed parameter
    // This is used to update the remove(after:) method to function using value semantics
    private mutating func copyNodes(returningCopyOf node: Node<Value>?) -> Node<Value>? {
        guard !isKnownUniquelyReferenced(&head) else { return nil }
        
        guard var oldNode = head else { return nil }
        
        head = Node(value: oldNode.value)
        var newNode = head
        var nodeCopy: Node<Value>?
        
        while let nextOldNode = oldNode.next {
            if oldNode === node {
                nodeCopy = newNode
            }
            newNode!.next = Node(value: nextOldNode.value)
            newNode = newNode!.next
            
            oldNode = nextOldNode
        }
        
        return nodeCopy
    }
}


extension LinkedList: CustomStringConvertible {
    public var description: String {
        guard let head = head else {
            return "Empty list"
        }
        
        return String(describing: head)
    }
}

// LinkedList adopts Collection protocol methods
// This allows for mapping an Index to a value
// Below: Define a custom index that has a reference to the next node
extension LinkedList: Collection {
    // 1: startIndex = defined as head of linked list
    public var startIndex: Index {
        Index(node: head)
    }
    
    // endIndex = index right after tail
    public var endIndex: Index {
        Index(node: tail?.next)
    }
    
    // index(after:) = determines how index is incremented
    // You can simply give it an index of the next node
    public func index(after i: Index) -> Index {
        Index(node: i.node?.next)
    }
    
    // O(1): subscript = used to map an Index to the value in the collection
    public subscript(position: Index) -> Value {
        position.node!.value
    }
    
    public struct Index: Comparable {
        public var node: Node<Value>?
        
        static public func ==(lhs: Index, rhs: Index) -> Bool {
            switch (lhs.node, rhs.node) {
            case let (left?, right?):
                return left.next === right.next
            case (nil, nil):
                return true
            default:
                return false
            }
        }
        
        static public func <(lhs: Index, rhs: Index) -> Bool {
            guard lhs != rhs else { return false }
            
            let nodes = sequence(first: lhs.node) { $0?.next }
            return nodes.contains { $0 === rhs.node }
        }
    }
}
