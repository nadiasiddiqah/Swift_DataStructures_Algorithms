// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.

// MARK: - BUILD LIST USING NODE
// Node class: Creates and links each node
// This method of building list is not great
example(of: "creating and linking nodes") {
    let node1 = Node(value: 1)
    let node2 = Node(value: 2)
    let node3 = Node(value: 3)
    
    node1.next = node2
    node2.next = node3
    
    print(node1)   // 1 -> 2 -> 3
}

// MARK: - ADD VALUES TO LIST USING LINKED LIST METHODS

// O(1): Push method - inserts at head
example(of: "push new node") {
    var list = LinkedList<Int>()
    list.push(3)
    list.push(2)
    list.push(1)
    
    print(list)   // 1 -> 2 -> 3
}

// O(1): Append method - inserts at tail
example(of: "append new node") {
    var list = LinkedList<Int>()
    list.append(1)
    list.append(2)
    list.append(3)
    
    print(list)   // 1 -> 2 -> 3
}

// O(i): node(at:) method - returns a node at given index
// i = given index (in this case: i = 1)
// O(1): insert(after:) method - inserts after a node
example(of: "inserting at a given index") {
    var list = LinkedList<Int>()
    list.push(3)
    list.push(2)
    list.push(1)
    
    print("Before inserting: \(list)")   // 1 -> 2 -> 3
    // Find node at given index
    var middleNode = list.node(at: 1)!
    
    // Inserts 4 new nodes of (-1) value after middleNode (node at given index)
    for _ in 1...4 {
        middleNode = list.insert(-1, after: middleNode)
    }
    print("After inserting: \(list)")   // 1 -> 2 -> -1 -> -1 -> -1 -> -1 -> 3
}


// MARK: - REMOVE VALUES FROM LIST USING LINKED LIST METHODS

// O(1): Pop method - removes at head
example(of: "pop offing first node") {
    var list = LinkedList<Int>()
    list.push(3)
    list.push(2)
    list.push(1)
    
    print("Before popping list: \(list)")  // 1 -> 2 -> 3
    
    let poppedValue = list.pop()
    print("After popping list: \(list)") // 2 -> 3
    print("Popped value: " + String(describing: poppedValue)) // Optional(1)
}


// O(1): removeLast method - removes at tail
example(of: "removing the last node") {
    var list = LinkedList<Int>()
    list.push(3)
    list.push(2)
    list.push(1)
    
    print("Before removing last node: \(list)")  // 1 -> 2 -> 3
    let removedValue = list.removeLast()
    
    print("After removing last node: \(list)")  // 1 -> 2
    print("Remove value: " + String(describing: removedValue))  // Optional(3)
}


// O(1) remove(after:) method - removes after's next node 
example(of: "removing a node after a given node") {
    var list = LinkedList<Int>()
    list.push(3)
    list.push(2)
    list.push(1)
    
    print("Before removing at given index: \(list)")  // 1 -> 2 -> 3
    let index = 1
    let node = list.node(at: index - 1)!
    let removedValue = list.remove(after: node)
    
    print("After removing at index \(index) : \(list)")  // index 1 : 1 -> 3
    print("Removed value: " + String(describing: removedValue))  // Optional(2)
}

// O(1) to access prefix or suffix nodes
example(of: "linked list adopting Collection to map Index to a value") {
    var list = LinkedList<Int>()
    for i in 0...9 {
        list.append(i)
    }
    
    print("List: \(list)")  // 0 -> 1 -> 2 -> 3 -> 4 -> 5 -> 6 -> 7 -> 8 -> 9
    print("First element: \(list[list.startIndex])")  // 0
    
    print("array containing first 3 elements: \(Array(list.prefix(3)))")  // [0, 1, 2]
    print("array containing last 3 elements: \(Array(list.suffix(3)))")  // [7, 8, 9]
    
    let sum = list.reduce(0, +)
    print("Sum of all values: \(sum)") // 45
}


// Example of array having value semantics
example(of: "array copy-on-write (cow)") {
    let array1 = [1, 2]
    var array2 = array1  // array2 copies array1
    
    print("array1: \(array1)")  // array1: [1, 2]
    print("array2: \(array2)")  // array2: [1, 2]
    
    print("---After adding 3 to array 2---")
    array2.append(3)  // append to array2
    
    print("array1: \(array1)")  // array1: [1, 2]
    print("array2: \(array2)")  // array2: [1, 2, 3]
}


// Example of linked list having value semantics (after updating with copyNodes func)
// Originally it had reference semantics bc underlying storage uses a reference type (Node)
// However, adding copyNodes func to each linked list method adds value semantics
example(of: "linked list copy-on-write (cow)") {
    var list1 = LinkedList<Int>()
    list1.append(1)
    list1.append(2)
    
    print("List1 uniquely referenced: \(isKnownUniquelyReferenced(&list1.head))") // true (has single strong reference)
    var list2 = list1
    print("List1 uniquely referenced: \(isKnownUniquelyReferenced(&list1.head))") // false (bc node objects are shared btwn list2 and list1)
    
    print("List1: \(list1)")  // List1: 1 -> 2
    print("List2: \(list2)")  // List2: 1 -> 2
    
    print("After appending 3 to list2")
    list2.append(3)
    
    print("List1: \(list1)")  // List1: 1 -> 2
    print("List2: \(list2)")  // List2: 1 -> 2 -> 3
    
    print("Removing middle node on list2")
    if let node = list2.node(at: 0) {
        list2.remove(after: node)
    }
    print("List2: \(list2)")  // List2: 1 -> 3
}
