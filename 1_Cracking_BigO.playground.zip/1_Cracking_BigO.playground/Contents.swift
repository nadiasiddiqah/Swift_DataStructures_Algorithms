import UIKit

// MARK: - Example 1
func foo(array: [Int]) {
    var sum = 0
    var product = 1
    
    // O(n) = constant time
    for i in array {
        sum += array[i]
    }
    
    // O(n) = constant time
    for i in array {
        product *= array[i]
    }
    
    print("\(sum) + "," + \(product)")
}
// Runtime: O(2n) -> O(n)
// Reduces bc looping through the same array twice


// MARK: - Example 2
func printPairs(array: [Int]) {
    for i in array {
        for j in array {
            print("\(array[i]) + "," + \(array[j])")
        }
    }
}
// Runtime: O(n^2) - quadratic time
// Doesn't matter if it loops through the same array twice


// MARK: - Example 3
//func printUnorderedPairs(array: [Int]) {
//    for i in array {
//        for i + 1 in array {
//            print("\(array[i]) + "," + \(array[i+1])")
//        }
//    }
//}
// Runtime: O(n^2) - quadratic time
// Doesn't matter if it loops through i vs i+1 of same array


// MARK: - Example 4
func printUnorderedPairs(arrayA: [Int], arrayB: [Int]) {
    // O(n)
    for i in arrayA {
        // O(m)
        for j in arrayB {
            // O(1)
            if arrayA[i] < arrayB[j] {
                print("\(arrayA[i]) + "," + \(arrayB[j])")
            }
        }
    }
}
// Runtime: O(n*m) - quadratic time
// This is bc it's a nested for loop, iterating two different arrays


// MARK: - Example 5
var arrayA = [1, 2, 3]
var arrayB = [1, 5, 6]
func printUnorderedPairs2(arrayA: [Int], arrayB: [Int]) {
    for i in arrayA {
        for j in arrayB {
            for i in 0..<100000 {
                print("\(arrayA[i]) + "," + \(arrayB[j])")
            }
        }
    }
}
// Runtime: O(n*m) - quadratic time
// Nothing changed. 10,000 units of work is still constant.


// MARK: - Example 6
var array = [1, 2, 3, 4]
func reverse(array: [Int]) {
    var reversedArray = [Int]()
    for i in 0..<array.count {
        let newIndex = array.count - 1 - i
        reversedArray.append(array[newIndex])
    }
    print(reversedArray)
}

reverse(array: array)
// Runtime: O(n) - constant time
// Loops through one array to reverse the array


// MARK: - Example 7
// Which is equal to O(n)?
    // 1. O(n+p), where p < n/2
        // n is the dominant term, so O(n)
    // 2. O(2n)
        // drop constant, so O(n)
    // 3. O(n + log n)
        // worst case, O(n)
    // 4. O(n + m) - separate loops


// MARK: - Example 9
//func sum(node: Node) {
//    if node == nil {
//        return 0
//    }
//
//    return sum(node.left) + node.value + sum(node.right)
//}
// Runtime: O(n) - constant time
// This is bc this function touches each node on the tree
// If there are N nodes, then runtime is O(n)


// MARK: - Example 10
func isPrime(n: Int) -> Bool {
    for i in 2..<n {
        if n % i == 0 {
            return false
        }
    }
    
    return true
}

isPrime(n: 2)

// Runtime: O(n/2) - root n time
// Loop starts at 2, and ends when i*i == n
// In order orders, it stops when x = n/2 (when x equals square root of n)

func power(a: Int, b: Int) -> Int {
    if b < 0 {
        return 0
    } else if b == 0 {
        return 1
    } else {
        return a * power(a: a, b: b-1)
    }
}
