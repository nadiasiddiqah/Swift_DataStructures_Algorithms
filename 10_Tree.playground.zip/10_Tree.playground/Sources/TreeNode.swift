import Foundation

// MARK: - Create generic TreeNode class
public class TreeNode<T> {
    
    // 2. Create variables to store each node's value + its references to its children (in an array)
    public var value: T
    public var children: [TreeNode] = []
    
    public init(_ value: T) {
        self.value = value
    }
    
    // 3. Add function to add new child nodes to a parent node
    public func add(_ child: TreeNode) {
        children.append(child)
    }
}



// MARK: - Creating depth-first traversal function
// This technique starts at the root, and vists nodes as deep as it can before backtracking
extension TreeNode {
    // Uses recursion to process the next node
    public func forEachDepthFirst(visit: (TreeNode) -> Void) {
        let currentNode = self
        visit(currentNode)
        
        currentNode.children.forEach { node in
            node.forEachDepthFirst(visit: visit)
        }
    }
}



// MARK: - Creating level-orer traversal function
// This technique visits each node of the nodes in level-order
extension TreeNode {
    public func forEachLevelOrder(visit: (TreeNode) -> Void) {
        visit(self)
        
        // Use queue to ensure you visit nodes in the right level order
        // Stack doesn't work here (recursion implicity uses stack)
        var queue = Queue<TreeNode>()
        
        children.forEach { child in
            queue.enqueue(child)
        }
        
        while let node = queue.dequeue() {
            visit(node)
            node.children.forEach { child in
                queue.enqueue(child)
            }
        }
    }
}



// MARK: - Build search algorithm
extension TreeNode where T: Equatable {
    public func search(_ value: T) -> TreeNode? {
        var result: TreeNode?
        
        // Use level-order traversal to search for the node 
        forEachLevelOrder { node in
            if node.value == value {
                result = node
            }
        }
        
        return result
    }
}
