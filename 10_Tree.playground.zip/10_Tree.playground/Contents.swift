// Copyright (c) 2021 Razeware LLC
// For full license & permission details, see LICENSE.markdown.

// MARK: - EXAMPLE 1
example(of: "Creating a tree") {
    let beverages = TreeNode("Beverages")
    
    let hot = TreeNode("Hot")
    let cold = TreeNode("Cold")
    
    beverages.add(hot)
    beverages.add(cold)
}


// MARK: - EXAMPLE 2
func makeBeverageTree() -> TreeNode<String> {
    let tree = TreeNode("Beverages")
    
    let hot = TreeNode("Hot")
    let cold = TreeNode("Cold")
    
    let tea = TreeNode("tea")
    let coffee = TreeNode("coffee")
    let chocolate = TreeNode("cocoa")
    let blackTea = TreeNode("black")
    let greenTea = TreeNode("green")
    let chaiTea = TreeNode("chai")
    let soda = TreeNode("soda")
    let milk = TreeNode("milk")
    let gingerAle = TreeNode("ginger ale")
    let bitterLemon = TreeNode("bitter lemon")
    
    tree.add(hot)
    tree.add(cold)
    hot.add(tea)
    hot.add(coffee)
    hot.add(chocolate)
    cold.add(soda)
    cold.add(milk)
    tea.add(blackTea)
    tea.add(greenTea)
    tea.add(chaiTea)
    soda.add(gingerAle)
    soda.add(bitterLemon)
    return tree
}

example(of: "Depth-first traversal") {
    let tree = makeBeverageTree()
    tree.forEachDepthFirst { node in
        print(node.value)
    }
}
/* 
 ---Example of: Depth-first traversal---
 Beverages
 Hot
 tea
 black
 green
 chai
 coffee
 cocoa
 Cold
 soda
 ginger ale
 bitter lemon
 milk
*/


// MARK: - EXAMPLE 3
example(of: "Level-order traversal") {
    let tree = makeBeverageTree()
    tree.forEachLevelOrder { node in
        print(node.value)
    }
}

/*
 ---Example of: Level-order traversal---
 Beverages
 Hot
 Cold
 tea
 coffee
 cocoa
 soda
 milk
 black
 green
 chai
 ginger ale
 bitter lemon

 */


// MARK: - SEARCH
example(of: "searching for a node") {
    let tree = makeBeverageTree()
    
    if let searchResult1 = tree.search("ginger ale") {
        print("Found node: \(searchResult1.value)")
    }
    
    if let searchResult2 = tree.search("WKD Blue") {
        print(searchResult2.value)
    } else {
        print("Couldn't find WKD Blue")
    }
}

/*
 ---Example of: searching for a node---
 Found node: ginger ale
 Couldn't find WKD Blue
 */


