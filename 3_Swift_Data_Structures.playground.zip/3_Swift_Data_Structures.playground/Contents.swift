import UIKit

struct Student: Hashable {
    var name: String
    var age: Int
}

// MARK: - Arrays

// 1. Data structure is a generic collection of elements
// Can hold Int, Str, or custom type elements
var scores: [Int] = [17, 28, 18, 88, 20]
var names: [String] = ["Poppy", "Laura", "Betty", "Dina"]
var students: [Student] = [Student(name: "Todd", age: 12),
                           Student(name: "Kyle", age: 11),
                           Student(name: "Mike", age: 10)]

// 2. O(1) - random access of elements
scores[0]     // 17
names[2]      // Betty
students[1]   // Student(name: "Kyle", age: 11)

// 3. O(1) - appending ONE element to end
scores.append(25)
names.append("Lorde")
students.append(Student(name: "Bob", age: 8))

// 4. O(n) - looking up elements
func findNewStudent(student: Student) -> Bool {
    // Requires looping from first index to last index to find an element
    for i in students {
        if i.name == student.name {
            return true
        }
    }
    
    return false
}

findNewStudent(student: Student(name: "Sheila", age: 10))

// 5. O(n) - insert or delete elements (anywhere except the end)
// Requires changing the index for every element
names.insert("Todd", at: 2)   // ["Poppy", "Laura", "Todd", "Betty", "Dina", "Lorde"]
names.remove(at: 0)           // ["Laura", "Todd", "Betty", "Dina", "Lorde"]

// 6. O(m) - adding multiple new elements
// m = number of new elements
// Requires doubling size of array, and copying existing elements into new array to make space for new elements
var newNames = ["Poppy", "Gina", "Beth"]
names.append(contentsOf: newNames)





// MARK: - Dictionary

// 1. Data structure that can hold generic collection of elements
// Can hold Int, Str, or custom type elements
// Custom type elements need to conform to Hashable
var cars: [String: Int] = ["Toyota": 2009, "Lambo": 1992, "Ferrari": 2020]
var favoriteColors: [Student: String] = [Student(name: "Todd", age: 12): "Blue",
                                 Student(name: "Sara", age: 10): "Yellow",
                                 Student(name: "Charlie", age: 11): "Pink"]

// 2. O(1): Insert new element
cars["Infiniti"] = 2001    // ["Lambo": 1992, "Ferrari": 2020, "Infiniti": 2001, "Toyota": 2009]
favoriteColors[Student(name: "Mason", age: 10)] = "Green"
// [__lldb_expr_32.Student(name: "Sara", age: 10): "Yellow", __lldb_expr_32.Student(name: "Mason", age: 10): "Green", __lldb_expr_32.Student(name: "Charlie", age: 11): "Pink", __lldb_expr_32.Student(name: "Todd", age: 12): "Blue"]


// 3. O(1): Looking up an element
var findInCars = cars["Ford"]    // nil (not in cars dictionary)
var findInFavoriteColors = favoriteColors[Student(name: "Sara", age: 10)]   // "Yellow"


// MARK: - Sets
// Data structure that stores unique elements + unordered
var animals: Set<String> = Set(["Frog", "Goat", "Koi", "Camel"])
var uniqueStudents: Set<Student> = Set([Student(name: "Anna", age: 10), Student(name: "George", age: 11)])

// 1. O(1): Fast retrieval
animals.contains("Lion")  // false
animals.contains("Frog")  // true

// 2. O(1): Turn array into set to quickly find an element
// Only works if all array elements are unique
var uniqueScores = Set(scores)
uniqueScores.contains(20)



// MARK: - TUPLES

// Data structure that is fixed in size
// Comma separated list of zero or more types, enclosed in parentheses
// You can't add or remove parameters, but you can update them

// 1. Need to create typealias to return multiple types
typealias ItemInfo = (item: String, size: String, sold: Bool)

// Use in functions to return multiple types
//func getItemInfo(item: String) -> (item: String, size: String, sold: Bool)? {  // returns tuple
func getItemInfo(item: String) -> ItemInfo? {  // return typealias
    let soldItems = ["Blouse", "Jacket"]
    if soldItems.contains(item) {
        let itemInfo = (item: item, size: "one-size", sold: true)
        return itemInfo
    }
    
    return nil
}

getItemInfo(item: "Blouse")   // (item: "Blouse", size: "one-size", sold: true)

